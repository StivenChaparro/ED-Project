/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package logica;
import gui.Pantalla;
  import java.util.*;
/**
 *
 * @author Fabian Abreo
 */



public class Restaurante {
    public static void main(String[] args) {
        // Menú del restaurante
        Pantalla panta=new Pantalla();
        panta.setVisible(true);
        panta.setLocationRelativeTo(null);
        Map<String, ProductoMenu> menu = new HashMap<>();
        menu.put("Pizza", new ProductoMenu("Pizza",15,5));
        menu.put("Ensalada", new ProductoMenu("Ensalada",5,4));
        menu.put("Limonada", new ProductoMenu("Limonada",2,6));

        // Cola FIFO de pedidos
        Queue<PedidoMesa> colaPedidos = new LinkedList<>();

        // Simular pedidos
        colaPedidos.add(new PedidoMesa(1, "Ana", List.of(menu.get("Pizza"), menu.get("Limonada"))));
        colaPedidos.add(new PedidoMesa(2, "Luis", List.of(menu.get("Ensalada"), menu.get("Limonada"))));
        colaPedidos.add(new PedidoMesa(3, "Pedro", List.of(menu.get("Pizza"), menu.get("Ensalada"))));

        // Mostrar pedidos pendientes
        System.out.println("Pedidos en cola:");
        for (PedidoMesa pedido : colaPedidos) {
            System.out.println(pedido);
        }

        // Despachar pedidos
        System.out.println("\nDespachando pedidos:");
        while (!colaPedidos.isEmpty()) {
            PedidoMesa pedido = colaPedidos.poll();
            System.out.println("Entregando mesa " + pedido.getMesa() + " atendida por " + pedido.getMesero());

            for (ProductoMenu producto : pedido.getProductos()) {
                producto.reducirInventario();
                System.out.println(" * " + producto.getNombre());
            }
        }

        // Inventario final
        System.out.println("\nInventario actualizado:");
        for (ProductoMenu p : menu.values()) {
            System.out.println(p);
        }
    }
}

    
    

